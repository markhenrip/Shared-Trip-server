CREATE PROCEDURE sp_search_events_by_location(IN p_location VARCHAR(50))
  BEGIN
  SELECT * 
  FROM sharedtrip.event_main e 
  WHERE UPPER(e.location) 
  LIKE UPPER(CONCAT('%', p_location, '%')); 
END;
