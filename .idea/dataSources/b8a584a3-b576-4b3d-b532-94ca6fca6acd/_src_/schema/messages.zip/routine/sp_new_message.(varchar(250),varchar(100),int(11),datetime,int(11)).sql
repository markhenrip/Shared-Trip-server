CREATE PROCEDURE sp_new_message(IN p_message   VARCHAR(250), IN p_topic VARCHAR(100), IN p_sender_id INT,
                                IN p_time_sent DATETIME, IN p_event_id INT)
  BEGIN
  IF NOT ISNULL(p_time_sent) THEN
    INSERT
    INTO temp_instant_messages(
      message
      , topic
      , sender_id
      , time_sent_utc
      , event_id)
    VALUES (
      p_message
      , p_topic
      , p_sender_id
      , p_time_sent
      , p_event_id);
    ELSE
      INSERT
    INTO temp_instant_messages(
      message
      , topic
      , sender_id
      , event_id
    )
    VALUES (
      p_message
      , p_topic
      , p_sender_id
      , p_event_id
    );
      END IF;
  SELECT
    LAST_INSERT_ID() AS message_id,
    CASE
      WHEN u.first_name IS NULL THEN u.name
      ELSE u.first_name
    END AS sender_name,
    u.user_pic AS sender_picture,
    e.trip_name,
    m.time_sent_utc
  FROM sharedtrip.user_info u
    JOIN sharedtrip.event_main e ON e.id = p_event_id
    JOIN messages.temp_instant_messages m ON m.id = LAST_INSERT_ID()
  WHERE u.id = p_sender_id;
END;
