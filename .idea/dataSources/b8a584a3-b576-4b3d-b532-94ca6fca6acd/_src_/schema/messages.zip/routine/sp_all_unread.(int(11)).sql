CREATE PROCEDURE sp_all_unread(IN p_user_id INT)
  BEGIN
  SELECT m.id message_id, m.sender_id, m.time_fcm_received_utc, m.message,
    e.id event_id, e.trip_name event_name, m.topic topic_name
  FROM messages.temp_instant_messages m
    JOIN sharedtrip.event_main e ON m.event_id = e.id
  WHERE
    (
      exists( -- user participates in event
      SELECT 1
      FROM sharedtrip.event_participation p
      WHERE p.event_id = e.id AND p.participator_id = p_user_id
    ) OR e.admin_id = p_user_id ) -- or is admin

    AND (
      NOT exists(-- and hasn't seen the message
          SELECT 1
          FROM messages.message_seen ms
          WHERE ms.message_id = m.id AND ms.user_id = p_user_id
      ) AND m.sender_id != p_user_id
  );
END;
