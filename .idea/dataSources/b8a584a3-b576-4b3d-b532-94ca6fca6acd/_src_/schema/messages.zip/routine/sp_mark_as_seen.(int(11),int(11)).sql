CREATE PROCEDURE sp_mark_as_seen(IN p_message_id INT, IN p_user_id INT)
  BEGIN
  INSERT INTO 
    messages.message_seen(message_id, user_id) 
  VALUES (p_message_id, p_user_id);
END;
