CREATE PROCEDURE sp_message_received_by_fcm(IN p_message_id INT, IN p_fcm_id VARCHAR(50))
  BEGIN
  UPDATE messages.temp_instant_messages
  SET
    fcm_id = p_fcm_id,
    time_fcm_received_utc = current_timestamp()
  WHERE id = p_message_id;
  SELECT * FROM messages.temp_instant_messages WHERE id = p_message_id;
END;
