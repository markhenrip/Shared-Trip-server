CREATE PROCEDURE sp_message_history(IN p_user_id INT, IN p_event_id INT, IN p_last_id INT)
  BEGIN
  SELECT
    m.*,
    CASE
      WHEN u.first_name IS NULL THEN u.name
      ELSE u.first_name
    END AS sender_name,
    u.user_pic sender_picture,
    exists( -- exists a seen entry or user is the sender
        SELECT 1
        FROM message_seen
        WHERE
          message_id = m.id AND
          user_id = p_user_id
    ) OR m.sender_id = p_user_id AS is_seen
  FROM messages.temp_instant_messages m
    JOIN sharedtrip.user_info u ON m.sender_id = u.id
  WHERE fcm_id IS NOT NULL AND
        event_id = p_event_id AND
        m.id > p_last_id
  ORDER BY time_fcm_received_utc DESC
  LIMIT 20;
END;
