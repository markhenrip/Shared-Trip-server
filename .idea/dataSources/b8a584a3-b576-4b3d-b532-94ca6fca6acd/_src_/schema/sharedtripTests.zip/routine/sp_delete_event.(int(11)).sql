CREATE PROCEDURE sp_delete_event(IN p_event_id INT)
  BEGIN
    DELETE FROM
      sharedtrip.event_main  WHERE id = p_event_id;
  END;
