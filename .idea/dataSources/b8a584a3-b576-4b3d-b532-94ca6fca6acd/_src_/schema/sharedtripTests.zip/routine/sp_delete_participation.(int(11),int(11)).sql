CREATE PROCEDURE sp_delete_participation(IN p_event_id INT, IN p_user_id INT)
  BEGIN
    DELETE FROM
      sharedtrip.event_participation  WHERE event_id = p_event_id AND participator_id = p_user_id;
  END;
