CREATE VIEW view_events AS
  SELECT
    `sharedtrip`.`event_main`.`event_picture` AS `event_picture`,
    `sharedtrip`.`event_main`.`total_cost`    AS `total_cost`,
    `sharedtrip`.`event_main`.`trip_name`     AS `trip_name`,
    `sharedtrip`.`event_main`.`location`      AS `location`,
    `sharedtrip`.`event_main`.`spots`         AS `spots`
  FROM `sharedtrip`.`event_main`;
