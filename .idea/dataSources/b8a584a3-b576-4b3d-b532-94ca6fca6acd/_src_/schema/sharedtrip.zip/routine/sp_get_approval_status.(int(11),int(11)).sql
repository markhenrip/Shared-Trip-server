CREATE PROCEDURE sp_get_approval_status(IN p_event_id INT, IN p_user_id INT)
  BEGIN
    SELECT admin_id=p_user_id AS is_admin, approved, banned
    FROM event_main e
      LEFT OUTER JOIN event_participation p
        ON p.event_id = e.id
    WHERE p.participator_id = p_user_id AND
          p.event_id=p_event_id;
  END;
