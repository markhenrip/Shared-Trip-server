CREATE PROCEDURE sp_update_user_description(IN p_id INT, IN p_text VARCHAR(100))
  BEGIN
    UPDATE sharedtrip.user_info SET user_desc = p_text WHERE id = p_id;
  END;
