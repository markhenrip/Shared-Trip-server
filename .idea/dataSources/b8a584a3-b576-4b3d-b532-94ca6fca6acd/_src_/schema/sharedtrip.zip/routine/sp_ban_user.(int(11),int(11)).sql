CREATE PROCEDURE sp_ban_user(IN p_event_id INT, IN p_user_id INT)
  BEGIN
    UPDATE event_participation
    SET
      approved = FALSE,
      banned = TRUE 
    WHERE event_id = p_event_id AND
          participator_id = p_user_id;
  END;
