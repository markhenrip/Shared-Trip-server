CREATE PROCEDURE sp_leave_event(IN p_event_id INT, IN p_user_id INT)
  BEGIN
    DECLARE was_banned BOOL;

    SELECT banned
    INTO was_banned
    FROM sharedtrip.event_participation 
    WHERE participator_id = p_user_id AND
          event_id = p_event_id;

    IF was_banned THEN 
      SELECT 'banned' as error_reason;
      
    ELSE
      DELETE FROM sharedtrip.event_participation
      WHERE participator_id = p_user_id AND
            event_id = p_event_id;
      
      SELECT (e.admin_id = p_user_id) AS is_admin
      FROM sharedtrip.event_main e
      WHERE e.id = p_event_id;
      
    END IF;
  END;
