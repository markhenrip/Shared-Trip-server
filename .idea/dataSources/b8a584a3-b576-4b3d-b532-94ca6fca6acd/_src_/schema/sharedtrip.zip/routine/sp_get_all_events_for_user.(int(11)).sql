CREATE PROCEDURE sp_get_all_events_for_user(IN p_user_id INT)
  BEGIN
    SELECT e.*,
      exists(
        SELECT 1 FROM event_participation
        WHERE event_id = e.id AND participator_id = p_user_id AND approved
      ) AS approved,
      exists(
        SELECT 1 FROM event_participation
        WHERE event_id = e.id AND participator_id = p_user_id AND NOT (banned OR approved)
      ) AS pending,
      exists(
        SELECT 1 FROM event_participation
        WHERE event_id = e.id AND participator_id = p_user_id AND banned
      ) AS banned,
      e.admin_id=p_user_id AS is_admin
    FROM event_main e;
  END;
