CREATE PROCEDURE sp_join_event(IN p_event_id INT, IN p_user_id INT)
  BEGIN
declare userexists BOOL;
SELECT EXISTS(SELECT 1 FROM event_participation where participator_id=p_user_id and event_id=p_event_id) INTO userexists;
IF NOT userexists THEN
    INSERT
      INTO sharedtrip.event_participation (event_id, participator_id)
      VALUES (p_event_id, p_user_id);
END IF;
END;
