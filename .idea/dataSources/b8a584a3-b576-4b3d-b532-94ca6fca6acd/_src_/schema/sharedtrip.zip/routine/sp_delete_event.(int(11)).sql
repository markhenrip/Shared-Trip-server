CREATE PROCEDURE sp_delete_event(IN p_event_id INT)
  BEGIN
	DELETE FROM event_main WHERE event_main.id = p_event_id;
END;
