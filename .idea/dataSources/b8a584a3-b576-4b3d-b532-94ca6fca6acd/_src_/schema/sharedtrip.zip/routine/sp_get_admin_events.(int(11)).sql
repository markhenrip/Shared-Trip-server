CREATE PROCEDURE sp_get_admin_events(IN p_user_id INT)
  BEGIN
    SELECT
      e.*, (
      SELECT count(*)
      FROM event_participation p
      WHERE
        p.event_id = e.id AND
        NOT (p.approved OR p.banned)
    ) AS users_pending
    FROM event_main e
    WHERE e.admin_id = p_user_id;
  END;
