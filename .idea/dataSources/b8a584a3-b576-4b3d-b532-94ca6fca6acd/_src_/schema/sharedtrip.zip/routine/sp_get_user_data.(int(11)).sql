CREATE PROCEDURE sp_get_user_data(IN p_user_id INT)
  BEGIN
    SELECT id,name,gender,birthdate,user_desc,user_pic FROM sharedtrip.user_info
    WHERE id=p_user_id;
  END;
