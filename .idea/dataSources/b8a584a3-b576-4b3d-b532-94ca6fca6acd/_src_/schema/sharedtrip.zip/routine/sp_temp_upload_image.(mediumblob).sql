CREATE PROCEDURE sp_temp_upload_image(IN p_content MEDIUMBLOB)
  BEGIN
INSERT INTO temp_image_upload(content) VALUES (p_content);
END;
