CREATE PROCEDURE sp_get_all_events()
  BEGIN
    SELECT *
    FROM event_main;
  END;
