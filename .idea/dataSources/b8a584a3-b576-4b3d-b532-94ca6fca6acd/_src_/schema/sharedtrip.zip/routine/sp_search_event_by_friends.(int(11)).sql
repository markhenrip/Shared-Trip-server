CREATE PROCEDURE sp_search_event_by_friends(IN p_user_id INT)
  BEGIN
    SELECT e.* FROM sharedtrip.event_main e
      LEFT JOIN sharedtrip.event_participation part ON e.id = part.event_id
    WHERE EXISTS(
      SELECT 1
      FROM sharedtrip.user_friends frens
      WHERE frens.friend_id = part.participator_id AND
            frens.user_id = p_user_id
            OR
            frens.user_id =  part.participator_id AND
            frens.friend_id = p_user_id
    );
  END;
