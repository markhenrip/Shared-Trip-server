CREATE PROCEDURE sp_event_creation(IN padmin_id   INT, IN plocation VARCHAR(50), IN ptrip_name VARCHAR(50),
                                   IN ptotal_cost INT, IN pspots INT, IN pdescription VARCHAR(200),
                                   IN pdate_begin DATETIME, IN pdate_end DATETIME, IN p_private TINYINT(1),
                                   IN p_picture   MEDIUMBLOB)
  BEGIN
    INSERT INTO event_main
    (admin_id, location, trip_name, total_cost, spots, description, date_begin, date_end, private, event_picture)
    VALUES (padmin_id, plocation, ptrip_name, ptotal_cost, pspots, pdescription, pdate_begin, pdate_end, p_private, p_picture);
    SELECT LAST_INSERT_ID() AS event_id;
END;
