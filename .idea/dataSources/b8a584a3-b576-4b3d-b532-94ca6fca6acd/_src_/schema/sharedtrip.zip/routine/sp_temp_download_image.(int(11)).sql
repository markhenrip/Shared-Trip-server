CREATE PROCEDURE sp_temp_download_image(IN p_id INT)
  BEGIN
SELECT encoded_value FROM temp_image_upload
WHERE id=p_id;
END;
