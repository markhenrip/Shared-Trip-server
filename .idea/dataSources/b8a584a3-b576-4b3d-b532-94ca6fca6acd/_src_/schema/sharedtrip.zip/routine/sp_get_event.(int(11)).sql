CREATE PROCEDURE sp_get_event(IN p_event_id INT)
  BEGIN
    SELECT * FROM event_main e WHERE e.id = p_event_id;
  END;
