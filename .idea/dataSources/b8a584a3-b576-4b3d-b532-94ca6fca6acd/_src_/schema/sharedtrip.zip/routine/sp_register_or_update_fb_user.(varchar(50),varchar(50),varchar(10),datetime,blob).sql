CREATE PROCEDURE sp_register_or_update_fb_user(IN p_fb_id     VARCHAR(50), IN p_name VARCHAR(50),
                                               IN p_gender    VARCHAR(10), IN p_birthdate DATETIME, IN p_user_pic BLOB)
  BEGIN
    DECLARE user_exists BOOLEAN;
    SELECT exists(SELECT 1 FROM sharedtrip.user_info WHERE fb_id = p_fb_id) INTO user_exists;

    IF user_exists THEN
      UPDATE sharedtrip.user_info
      SET name = p_name
        , gender = p_gender
        , birthdate = p_birthdate
        , user_pic = p_user_pic
      WHERE fb_id = p_fb_id;
    ELSE
      INSERT INTO sharedtrip.user_info(name, gender, birthdate, user_pic, fb_id)
        VALUES (p_name, p_gender, p_birthdate, p_user_pic, p_fb_id);
    END IF;
    SELECT id, user_desc FROM sharedtrip.user_info WHERE fb_id = p_fb_id;
  END;
