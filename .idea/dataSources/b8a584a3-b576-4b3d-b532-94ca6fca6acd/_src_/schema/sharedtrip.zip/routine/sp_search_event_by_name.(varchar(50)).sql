CREATE PROCEDURE sp_search_event_by_name(IN in_name VARCHAR(50))
  BEGIN 
SELECT * 
FROM event_main e 
WHERE UPPER(e.trip_name) 
    LIKE UPPER(CONCAT('%', in_name, '%')); 
END;
