CREATE PROCEDURE sp_get_pending_participators(IN p_event_id INT)
  BEGIN
    SELECT u.*
    FROM event_participation p LEFT OUTER JOIN user_info u ON p.participator_id = u.id
    WHERE p.event_id = p_event_id AND NOT (approved OR banned);
  END;
