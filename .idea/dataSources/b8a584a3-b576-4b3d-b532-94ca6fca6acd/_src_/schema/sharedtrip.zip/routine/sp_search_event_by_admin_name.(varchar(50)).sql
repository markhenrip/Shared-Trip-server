CREATE PROCEDURE sp_search_event_by_admin_name(IN p_admin_name VARCHAR(50))
  BEGIN
   SELECT e.*
    FROM event_main e
      LEFT OUTER JOIN user_info info
        ON e.admin_id = info.id
    WHERE UPPER(info.name)
    LIKE UPPER(CONCAT('%', p_admin_name, '%'));
  END;
