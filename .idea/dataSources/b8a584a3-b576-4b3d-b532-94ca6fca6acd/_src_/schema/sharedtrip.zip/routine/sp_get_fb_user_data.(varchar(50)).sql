CREATE PROCEDURE sp_get_fb_user_data(IN p_user_id VARCHAR(50))
  BEGIN
    SELECT id,name,gender,birthdate,user_desc,user_pic FROM sharedtrip.user_info
    WHERE fb_id=p_user_id;
  END;
