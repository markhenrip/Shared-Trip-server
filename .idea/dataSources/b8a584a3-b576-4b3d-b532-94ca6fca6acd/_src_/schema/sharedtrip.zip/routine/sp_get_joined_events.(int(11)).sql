CREATE PROCEDURE sp_get_joined_events(IN p_user_id INT)
  BEGIN
    SELECT * FROM sharedtrip.event_main e WHERE exists(
      SELECT 1 FROM event_participation p 
      WHERE p.event_id = e.id AND p.participator_id = p_user_id
    );
  END;
