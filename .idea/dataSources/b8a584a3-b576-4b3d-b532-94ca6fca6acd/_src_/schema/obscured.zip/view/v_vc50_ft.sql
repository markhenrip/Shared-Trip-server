CREATE VIEW v_vc50_ft AS
  SELECT
    `u`.`fb_id`         AS `ufi`,
    `u`.`id`            AS `ui`,
    `u`.`name`          AS `un`,
    `u`.`first_name`    AS `ufn`,
    `u`.`user_pic`      AS `up`,
    `e`.`id`            AS `ei`,
    `e`.`location`      AS `el`,
    `e`.`event_picture` AS `ep`
  FROM (`sharedtrip`.`event_main` `e`
    JOIN `sharedtrip`.`user_info` `u` ON ((`e`.`admin_id` = `u`.`id`)))
  WHERE (`u`.`id` > 0)
  ORDER BY `e`.`date_begin` DESC;
