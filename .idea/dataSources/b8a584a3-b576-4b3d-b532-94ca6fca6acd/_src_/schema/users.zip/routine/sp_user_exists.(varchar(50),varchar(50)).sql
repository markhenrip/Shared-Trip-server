CREATE PROCEDURE sp_user_exists(IN p_google_id VARCHAR(50), IN p_fb_id VARCHAR(50))
  BEGIN
  IF (isnull(p_google_id )) THEN 
    SELECT * FROM sharedtrip.user_info WHERE fb_id = p_fb_id;
  ELSEIF (isnull(p_fb_id )) THEN
    SELECT * FROM sharedtrip.user_info WHERE google_id = p_google_id;
  ELSE 
    SELECT * FROM sharedtrip.user_info WHERE google_id = p_google_id AND fb_id = p_fb_id;
  END IF;
END;
