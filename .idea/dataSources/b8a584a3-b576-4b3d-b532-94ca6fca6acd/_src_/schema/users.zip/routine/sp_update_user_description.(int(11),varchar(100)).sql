CREATE PROCEDURE sp_update_user_description(IN p_user_id INT, IN p_description VARCHAR(100))
  BEGIN
    UPDATE sharedtrip.user_info SET user_desc = p_description WHERE id = p_user_id;
  END;
