CREATE PROCEDURE sp_create_google_user(IN p_google_id VARCHAR(50), IN p_name VARCHAR(50), IN p_gender VARCHAR(10),
                                       IN p_user_pic  BLOB)
  BEGIN
    DECLARE user_exists BOOLEAN;
    SELECT exists(SELECT 1 FROM sharedtrip.user_info WHERE google_id = p_google_id) INTO user_exists;

    IF user_exists THEN
      UPDATE sharedtrip.user_info
      SET name = p_name
        , gender = p_gender
        , user_pic = p_user_pic
      WHERE google_id = p_google_id;
    ELSE
      INSERT INTO sharedtrip.user_info(name, gender, user_pic, google_id)
        VALUES (p_name, p_gender, p_user_pic, p_google_id);
    END IF;
    SELECT * FROM sharedtrip.user_info WHERE google_id = p_google_id;
  END;
