CREATE PROCEDURE sp_update_event_start_date(IN p_event_id INT, IN p_start_date DATETIME)
  BEGIN
    UPDATE sharedtrip.event_main e SET e.date_begin = p_start_date WHERE e.id = p_event_id;
  END;
