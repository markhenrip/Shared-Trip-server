CREATE PROCEDURE sp_update_event_admin(IN p_event_id INT, IN p_admin_id INT)
  BEGIN
    UPDATE sharedtrip.event_main e SET e.admin_id = p_admin_id WHERE e.id = p_event_id;
  END;
