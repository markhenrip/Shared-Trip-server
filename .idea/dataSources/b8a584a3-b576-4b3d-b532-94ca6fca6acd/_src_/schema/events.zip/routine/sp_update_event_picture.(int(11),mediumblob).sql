CREATE PROCEDURE sp_update_event_picture(IN p_event_id INT, IN p_picture MEDIUMBLOB)
  BEGIN
    UPDATE sharedtrip.event_main e SET e.event_picture = p_picture WHERE e.id = p_event_id;
  END;
