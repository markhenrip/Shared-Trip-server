CREATE PROCEDURE sp_update_event_location(IN p_event_id INT, IN p_location VARCHAR(50))
  BEGIN
    UPDATE sharedtrip.event_main e SET e.location = p_location WHERE e.id = p_event_id;
  END;
