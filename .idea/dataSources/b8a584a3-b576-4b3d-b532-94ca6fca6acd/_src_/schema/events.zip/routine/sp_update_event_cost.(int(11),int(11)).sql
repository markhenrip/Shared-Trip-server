CREATE PROCEDURE sp_update_event_cost(IN p_event_id INT, IN p_cost INT)
  BEGIN
    UPDATE sharedtrip.event_main e SET e.total_cost = p_cost WHERE e.id = p_event_id;
  END;
