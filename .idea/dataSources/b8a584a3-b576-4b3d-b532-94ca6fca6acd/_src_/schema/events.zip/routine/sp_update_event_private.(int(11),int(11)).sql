CREATE PROCEDURE sp_update_event_private(IN p_event_id INT, IN p_private INT)
  BEGIN
    UPDATE sharedtrip.event_main e SET e.private = p_private WHERE e.id = p_event_id;
  END;
