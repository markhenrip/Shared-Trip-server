CREATE PROCEDURE sp_update_event_spots(IN p_event_id INT, IN p_spots INT)
  BEGIN
    UPDATE sharedtrip.event_main e SET e.spots = p_spots WHERE e.id = p_event_id;
  END;
