CREATE PROCEDURE sp_update_event_name(IN p_event_id INT, IN p_name VARCHAR(50))
  BEGIN
    UPDATE sharedtrip.event_main e SET e.trip_name = p_name WHERE e.id = p_event_id;
  END;
