CREATE PROCEDURE sp_update_event_description(IN p_event_id INT, IN p_description VARCHAR(200))
  BEGIN
    UPDATE sharedtrip.event_main e SET e.description = p_description WHERE e.id = p_event_id;
  END;
