CREATE PROCEDURE sp_update_event_end_date(IN p_event_id INT, IN p_end_date DATETIME)
  BEGIN
    UPDATE sharedtrip.event_main e SET e.date_end = p_end_date WHERE e.id = p_event_id;
  END;
